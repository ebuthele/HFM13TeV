void runGrid()
{
  // Load common libraries
  gSystem->Load("libCore.so");  
  gSystem->Load("libTree.so");
  gSystem->Load("libGeom.so");
  gSystem->Load("libVMC.so");
  gSystem->Load("libPhysics.so");
  gSystem->Load("libMinuit.so");
  gSystem->Load("libSTEERBase");
  gSystem->Load("libESD");
  gSystem->Load("libAOD");
  gSystem->Load("libANALYSIS");
  gSystem->Load("libANALYSISalice");
  gSystem->Load("libCORRFW");
  gSystem->Load("libPWGmuon");
  gROOT->ProcessLine(".include $ROOTSYS/include");
   gROOT->ProcessLine(".include  $ALICE_ROOT/include");
gSystem->SetIncludePath("-I. -I/include -I$ROOTSYS/include -I$ALICE_ROOT/MUON -I$ALICE_ROOT/include -I$ALICE_PHYSICS/include");
  
  // Create and configure the alien handler plugin
  gROOT->LoadMacro("CreateAlienHandler.C");
  AliAnalysisGrid *alienHandler = CreateAlienHandler();  
  if (!alienHandler) return;

  // Create the analysis manager
 AliAnalysisManager *mgr = new AliAnalysisManager("AliAnalysisExamplePt");

  // Connect plug-in to the analysis manager
  mgr->SetGridHandler(alienHandler);

  gROOT->LoadMacro("AliAnalysisExamplePt.cxx++g");   
 
  AliAODInputHandler *aodH = new AliAODInputHandler();
  mgr->SetInputEventHandler(aodH);

 AliAnalysisExamplePt *task = new AliAnalysisExamplePt("AliAnalysisExamplePt");

  // Create containers for input/output
  AliAnalysisDataContainer *cinput = mgr->GetCommonInputContainer();
  AliAnalysisDataContainer *coutput = mgr->CreateContainer("chist", TList::Class(),    AliAnalysisManager::kOutputContainer, "gridoutput.AOD.1.root");

  // Connect input/output
  mgr->AddTask(task);
  mgr->ConnectInput(task, 0, cinput);
  mgr->ConnectOutput(task, 1, coutput);

  // Enable debug printouts
  mgr->SetDebugLevel(0);

  if (!mgr->InitAnalysis())
    return;

  mgr->PrintStatus();
  // Start analysis in locally
  // mgr->StartAnalysis("local");
  // Start analysis in grid
  mgr->StartAnalysis("grid");
};
