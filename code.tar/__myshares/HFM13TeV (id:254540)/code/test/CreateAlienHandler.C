 AliAnalysisGrid* CreateAlienHandler()
{
// Check if user has a valid token, otherwise make one. This has limitations.
// One can always follow the standard procedure of calling alien-token-init then
//   source /tmp/gclient_env_$UID in the current shell.
//   if (!AliAnalysisGrid::CreateToken()) return NULL;
   AliAnalysisAlien *plugin = new AliAnalysisAlien();

// Overwrite all generated files, datasets and output results from a previous session
   plugin->SetOverwriteMode();
// Set the run mode (can be "full", "test", "offline", "submit" or "terminate")
   plugin->SetRunMode("full");  // VERY IMPORTANT - DECRIBED BELOW
// Set versions of used packages
   plugin->SetAPIVersion("V1.1x");
   plugin->SetAliPhysicsVersion("vAN-20180724-1");
//   plugin->SetAliPhysicsVersion("vAN-20171031-1");
// Declare input data to be processed.

//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*

// Method 1: Create automatically XML collections using alien 'find' command.
 
  // Set data search pattern
  plugin->SetGridDataDir("/alice/data/2017/LHC17h/6Nov/");
  plugin->SetRunPrefix("000");
  plugin->SetDataPattern("muon_calo_pass2/AOD/*/AliAOD.Muons.root");
// // ...then add run numbers to be considered
   

//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//*//

//    plugin->SetFileForTestMode("runlis.ttxt");
     const char *runListName = "LHC17hrunlist.txt";
     if(!runListName) {
 	cout << "run list file name does not exist... stop now!" <<endl;
 	return NULL;
 	}
 	    ifstream runListFile;
 	    runListFile.open((char*)runListName);
 	    Int_t runNr;
 	    if (runListFile.is_open()) {
 	      while (kTRUE){
 		runListFile >> runNr;
 		if(runListFile.eof()) break;
 		cout<<runNr<<"\n";
 		plugin->AddRunNumber(runNr);
 	      }
 	}
 	  else {
 	      cout << "run list file "<<runListName<<" does not exist... stop now!" <<endl;
 	      return NULL;
 	}
   runListFile.close();

// Define alien work directory where all files will be copied. Relative to alien $HOME.
   plugin->SetGridWorkingDir("work");
// Declare alien output directory. Relative to working directory.
   plugin->SetGridOutputDir("output"); // In this case will be $HOME/work/output
// Declare the analysis source files names separated by blancs. To be compiled runtime
// using ACLiC on the worker nodes.
   plugin->SetAnalysisSource("AliAnalysisExamplePt.cxx");
// Declare all libraries (other than the default ones for the framework. These will be
// loaded by the generated analysis macro. Add all extra files (task .cxx/.h) here.
   plugin->SetAdditionalLibs("AliAnalysisExamplePt.h AliAnalysisExamplePt.cxx libSTEERBase.so libESD.so libAOD.so libANALYSIS.so libOADB.so libANALYSISalice.so libCORRFW.so libGui.so libMinuit.so libProofPlayer.so libRAWDatabase.so libCDB.so libSTEER.so libMUONcore.so libMUONmapping.so libMUONgeometry.so libMUONcalib.so libMUONtrigger.so libMUONraw.so libMUONbase.so libMUONrec.so libMUONevaluation.so libPWGmuon.so");
// No need for output file names. Procedure is automatic.
//   plugin->SetOutputFiles("Pt.ESD.1.root");
//   plugin->SetDefaultOutputs();
// No need define the files to be archived. Note that this is handled automatically by the plugin.
//   plugin->SetOutputArchive("log_archive.zip:stdout,stderr");
// Set a name for the generated analysis macro (default MyAnalysis.C) Make this unique !
   plugin->SetAnalysisMacro("AnalysisPt.C");
// Optionally set maximum number of input files/subjob (default 100, put 0 to ignore). The optimum for an analysis
// is correlated with the run time - count few hours TTL per job, not minutes !
//   plugin->SetSplitMaxInputFileNumber(100);
// Optionally set number of failed jobs that will trigger killing waiting sub-jobs.
   plugin->SetMaxInitFailed(5);
// Optionally resubmit threshold.
 //  plugin->SetMasterResubmitThreshold(90);
// Optionally set time to live (default 30000 sec)
 //  plugin->SetTTL(20000);
// Optionally set input format (default xml-single)
  // plugin->SetInputFormat("xml-single");
// Optionally modify the name of the generated JDL (default analysis.jdl)
  // plugin->SetJDLName("TaskPt.jdl");
// Optionally modify job price (default 1)
 //  plugin->SetPrice(1); 
// Optionally modify split mode (default 'se')    
  // plugin->SetSplitMode("se");
// plugin->SetNtestFiles(5000);
   plugin->AddIncludePath("-I.");
   plugin->AddIncludePath("-I$ALICE_ROOT/include");
   plugin->AddIncludePath("-I$ALICE_PHYSICS/include");
//    plugin->SetNtestFiles(25);
   plugin->SetOutputToRunNo();
//plugin->SetMergeViaJDL();
   return plugin;
} 
