#ifndef AliAnalysisExamplePt_cxx
#define AliAnalysisExamplePt_cxx

// example of an analysis task creating a p_t spectrum
// Authors: Panos Cristakoglou, Jan Fiete Grosse-Oetringhaus, Christian Klein-Boesing

class TH1F;
class AliAODEvent;
class AliAODTrack;
class AliMuonTrackCuts;
class AliMuonEventCuts;
#include "AliAnalysisTaskSE.h"

class AliAnalysisExamplePt : public AliAnalysisTaskSE {
 public:
  AliAnalysisExamplePt() : AliAnalysisTaskSE(), fAOD(0),fMuonTrackCuts(0), fMuonEventCuts(0),  fHistEta(0), fHistVertex(0), fHistPt(0), fHistpDCA(0), fTrack(0) {}

  AliAnalysisExamplePt(const char *name);
  virtual ~AliAnalysisExamplePt() {}
  
  virtual void   UserCreateOutputObjects();
  virtual void   NotifyRun();
  virtual void   UserExec(Option_t *option);
  virtual void   Terminate(Option_t *);
  
  AliMuonTrackCuts* GetMuonTrackCuts() { return fMuonTrackCuts; }
  AliMuonEventCuts* GetMuonEventCuts() {return fMuonEventCuts;}
    
 private:
  AliAODEvent *fAOD;    //! ESD object
  TList       *fOutputList; //! Output list
  TH1F	      *fHistVertex;
  TH1F	      *fHistPt;
  TH1F        *fHistEta;
  TH2D 	      *fHistpDCA;

  Char_t    fTrigClass[200];
//   vector<Int> fTrigger;
  
  AliMuonTrackCuts* fMuonTrackCuts;
  AliMuonEventCuts* fMuonEventCuts;
   
  AliAODTrack *fTrack;
  AliAnalysisExamplePt(const AliAnalysisExamplePt&); // not implemented
  AliAnalysisExamplePt& operator=(const AliAnalysisExamplePt&); // not implemented
  
  ClassDef(AliAnalysisExamplePt, 1); // example of analysis
};

#endif
