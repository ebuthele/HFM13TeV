void rec() {
  AliReconstruction reco;
// run/run (No RejectList)
  reco.SetCleanESD(kFALSE);
  reco.SetStopOnError(kFALSE);
  reco.SetRunQA("MUON:ALL");
  //reco.SetRunLocalReconstruction("MUON");
  //reco.SetRunTracking("MUON");
  //reco.SetFillESD("MUON");
  //reco.SetRunVertexFinder(kFALSE);
  ////kTRUE by default (kFALSE if no SPD/ITS)
  reco.SetRunReconstruction("MUON");
// Default = raw OCDB
  reco.SetDefaultStorage("alien://Folder=/alice/data/2017/
  OCDB");
// GRP from local OCDB
  reco.SetSpecificStorage("GRP/GRP/Data", 
  Form("local://%s",gSystem->pwd()));
  //AliCDBManager* man = AliCDBManager::Instance();
  //man->SetDefaultStorage("alien://folder=/alice/data/2015/
  //OCDB");
  //man->SetSpecificStorage("GRP/GRP/Data",
  //Form("local://%s",gSystem->pwd()));
  //man->SetSpecificStorage("MUON/Align/Data", 
  //"alien://folder=/alice/data/2015/OCDB",5);
  TStopwatch timer;
  timer.Start();
  reco.Run();
  timer.Stop();
  timer.Print();
}
