#include <math.h>
#include <iostream.h>
void NormFinal()
{
    const double f_rev = 11245;
    const int n=102;
    int Run;
    double L0b_CINT7,L0b_CMSL7,L0b_CMSH7,Nb,PF_CINT7,PF_CMSL7,
    PF_CMSH7,CF_CINT7;
    
    double CF_MB,PF_MB,L0b_MB;
 
    double FNorm_MSL;
    double FNorm_MSH;
    
    double SigmaMSL;
    double SigmaMSH;
    
    double FNormErrMSL;
    double FNormErrMSH;
    
    double FNorm_MSL_Final1;
    double FNorm_MSH_Final1;
    double FNorm_MSL_Final2;
    double FNorm_MSH_Final2;
    double FNorm_MSL_Final;
    double FNorm_MSH_Final;
    
    double FNormErrMSL_Final;
    double FNormErrMSH_Final;
    
    ifstream fin("AnalysisFNorm_Scalar_LHC17k.txt");
    
    cout << "Run" << setw(20) << "FNorm_MSL" << setw(15) 
    << "FNormErrMSL" << setw(15) << "FNorm_MSH" << setw(15) 
    << "FNormErrMSH" << endl;
    for(int i=0; i<n;i++)
    {
///////////////////////////////////////////////////////////

        fin >> Run  >> L0b_CINT7 >> L0b_CMSH7 >> L0b_CMSL7 
        >> Nb >> PF_CINT7 >> PF_CMSH7 >> PF_CMSL7  
        >> CF_CINT7;
        
        // C0TVX MB Trigger
         CF_MB = CF_CINT7; // CF_CINT7;
         PF_MB = PF_CINT7; // PF_CINT7;
         L0b_MB = L0b_CINT7; // L0b_CINT7;
        
        // MSL Trigger FNorm & FNormErr
        FNorm_MSL = (L0b_MB*PF_MB*CF_MB)/
        (L0b_CMSL7*PF_CMSL7);
        SigmaMSL = sqrt((1/L0b_MB)+(1/L0b_CMSL7));
        FNormErrMSL = FNorm_MSL*SigmaMSL;
        
        FNorm_MSL_Final1+=FNorm_MSL/pow(SigmaMSL,2);
        // Numerator
        FNorm_MSL_Final2+=(1/pow(SigmaMSL,2)); 
        // denominator
        
        // MSH Trigger FNorm & FNormErr
        FNorm_MSH = (L0b_MB*PF_MB*CF_MB)/
        (L0b_CMSH7*PF_CMSH7);
        SigmaMSH = (1/L0b_MB)+(1/L0b_CMSH7);
        FNormErrMSH = FNorm_MSH*SigmaMSH;
        
        FNorm_MSH_Final1+=(FNorm_MSH/pow(SigmaMSH,2));
        FNorm_MSH_Final2+=(1/pow(SigmaMSH,2));
        
        cout << Run << setw(15) << FNorm_MSL << 
        setw(15) 
        << FNormErrMSL << setw(15) << FNorm_MSH << 
        setw(15) << FNormErrMSH << endl;
    }
///////////////////////////////////////////////////////////
   
    fin.close();
    
    FNorm_MSL_Final = FNorm_MSL_Final1/(double)
    FNorm_MSL_Final2;
    FNorm_MSH_Final = FNorm_MSH_Final1/(double)
    FNorm_MSH_Final2;
  
    cout << "FNorm_MSL_final = " << FNorm_MSL_Final 
    << endl;
    cout << "FNormErrMSL_Final = " 
    << FNorm_MSL_Final*sqrt(1/FNorm_MSL_Final2) 
    << endl;

    cout << "FNorm_MSH_final = " << FNorm_MSH_Final 
    << endl;
    cout << "FNormErrMSH_Final = "
    << FNorm_MSH_Final*sqrt(1/FNorm_MSH_Final2) 
    << endl;
}

