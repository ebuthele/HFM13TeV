#include "TChain.h"
#include "TTree.h"
#include "TH1F.h"
#include "TCanvas.h"
#include <iostream>
#include "AliAnalysisTask.h"
#include "AliAnalysisManager.h"
#include "AliAODEvent.h"
#include "AliAODTrack.h"
#include "AliMuonTrackCuts.h"
#include "AliAODInputHandler.h"
#include "AliAnalysisExamplePt.h"
#include "AliAODVertex.h"
#include "AliMuonEventCuts.h"

// example of an analysis task creating a p_t spectrum
// Authors: Panos Cristakoglou, Jan Fiete Grosse-Oetringhaus,
//Christian Klein-Boesing
// Reviewed: A.Gheata (19/02/10)
ClassImp(AliAnalysisExamplePt)
//__________________________________________________________
//**//	Here is where you initialise your objects     //**//
//**//	Make sure to declare in AliAnalysisExamplePt.h//**//
AliAnalysisExamplePt::AliAnalysisExamplePt(const char *name) 
  : AliAnalysisTaskSE(name),fAOD(0),fMuonTrackCuts(0), 
  fMuonEventCuts(0), fOutputList(0), fHistEta(0), 
  fHistVertex(0), fHistPt(0), fHistpDCA(0), fTrack(0)
{
  // Constructor
fMuonTrackCuts = new AliMuonTrackCuts(Form
("TrackCuts_%s",name), "TrackCuts");
fMuonTrackCuts->SetFilterMask(AliMuonTrackCuts::kMuEta
|AliMuonTrackCuts::kMuThetaAbs|AliMuonTrackCuts::kMuMatchLpt 
|AliMuonTrackCuts::kMuPdca);
//--------------------------------------------------------//
//**//Implement Physics selection on events//**//
fMuonEventCuts = new AliMuonEventCuts("event","event");
fMuonEventCuts->SetFilterMask(AliMuonEventCuts::kSelectedTrig 
| AliMuonEventCuts::kPhysicsSelected |
AliMuonEventCuts::kGoodVertex);
fMuonEventCuts->SetTrigClassPatterns("CMSH7-B-NOPF-MUFAST");
//---------------------------------------------------------//

Bool_t useMC = kFALSE;
fMuonTrackCuts->SetIsMC(useMC); //montecarlo
fMuonTrackCuts->Print("mask"); 
fMuonTrackCuts->SetAllowDefaultParams(kTRUE);
fMuonTrackCuts->ApplySharpPtCutInMatching(kTRUE);
  // Define input and output slots here
  // Input slot #0 works with a TChain
  DefineInput(0, TChain::Class());
  // Output slot #0 id reserved by the base class for AOD
  // Output slot #1 writes into a TH1 container
  DefineOutput(1, TList::Class());
}
//__________________________________________________________
void AliAnalysisExamplePt::UserCreateOutputObjects()
{
  // Create histograms
  // Called once

  fOutputList = new TList();
  
///////////////////////////////////////////////////////////
   
    fHistVertex=new TH1F("fHistVertex","Vertex distribution",
    60, -15, 15);
    fHistVertex->GetXaxis()->SetTitle("Z vertex (cm)");
    fHistVertex->GetYaxis()->SetTitle("Events");
    fHistVertex->SetMarkerStyle(kFullCircle);

    fHistpDCA = new TH2D("fHistpDCA", "p_{T} vs pDCA",
    1000, 0, 20,  10000, 0, 100000);
    fHistpDCA->GetXaxis()->SetTitle("p_{T} (GeV/c)");
    fHistpDCA->GetYaxis()->SetTitle("pDCA");
    fHistpDCA->SetMarkerStyle(kFullCircle);
    
    fHistPt = new TH1F("fHistPt", "P_{T} distribution", 
    10000, 0, 100);
    fHistPt->GetXaxis()->SetTitle("P_{T} (GeV/c)");
    fHistPt->GetYaxis()->SetTitle("dN/dP_{T} (c/GeV)");
    fHistPt->SetMarkerStyle(kFullCircle);
        
    fHistEta = new TH1F("fHistEta", "Eta distribution ", 
    240,-4.2,-2.4);
    fHistEta->GetXaxis()->SetTitle("#eta");
    fHistEta->GetYaxis()->SetTitle("dN/d#eta_{lab} (c/GeV)");
    fHistEta->SetMarkerStyle(kFullCircle);
    
///////////////////////////////////////////////////////////
  
    fOutputList->Add(fHistVertex);
    fOutputList->Add(fHistpDCA);   
    fOutputList->Add(fHistPt);
    fOutputList->Add(fHistEta); 
    
///////////////////////////////////////////////////////////

    PostData(1,fHistVertex);
    PostData(1,fHistpDCA);
    PostData(1,fHistPt);
    PostData(1,fHistEta);

///////////////////////////////////////////////////////////

    PostData(1,fOutputList);
}
///////////////////////////////////////////////////////////

void AliAnalysisExamplePt::NotifyRun()
{
  fMuonTrackCuts->SetRun(fInputHandler);
}
//_________________________________________________________
void AliAnalysisExamplePt::UserExec(Option_t * /*option*/)
{
  // Main loop
  // Called for each event
  // Post output data.
  fAOD = dynamic_cast<AliAODEvent*>(InputEvent());
  if (!fAOD) {
    printf("ERROR: fAOD not available\n");
    return;
  }

//-------------------------------------------------------//
  if (!fMuonEventCuts->IsSelected(fInputHandler) )return;
//-------------------------------------------------------//    

AliAODVertex *vz = fAOD->GetPrimaryVertexSPD();
if (vz->GetZ() >-10. && vz->GetZ() < 10. ){
fHistVertex->Fill(vz->GetZ());
}
//Loop over the events
for ( Int_t iTracks = 0; iTracks < fAOD->GetNumberOfTracks(); 
iTracks++ ) 
{
    AliAODTrack* track = dynamic_cast<AliAODTrack*>
    (fAOD->GetTrack(iTracks));
    if (!track) {
      printf("ERROR: Could not receive track %d\n", iTracks);
      continue;      
    }
//---------------------------------------------------------//      
if(!fMuonTrackCuts->IsSelected(track)) continue;
//---------------------------------------------------------//  
// PT DISTRIBUTION WITH DCA
    
    fHistpDCA->Fill(track->Pt(),track->P()*track->DCA());
    
// PT DISTRIBUTION 
  
     fHistPt->Fill(track->Pt());
    
// // Eta DISTRIBUTION
    
     fHistEta->Fill(track->Eta());

  } //track loop 
  PostData(1, fOutputList);
}      

//___________________________________________________________
void AliAnalysisExamplePt::Terminate(Option_t *) 
{
  // Draw result to the screen
  // Called once at the end of the query

    fOutputList = dynamic_cast<TList*>(GetOutputData(1));
    if (!fOutputList) {
        printf("ERROR: Output list not available\n");
        return;
    }

    fHistVertex= dynamic_cast<TH1F*> (fOutputList->At(0));
    if (!fHistVertex) {
        printf("ERROR: fHistVertex not available\n");
        return;
    }  

    fHistpDCA = dynamic_cast<TH2D*> (fOutputList->At(1));
    if (!fHistpDCA) {
        printf("ERROR: fHistpDCA not available\n");
        return;
    } 
    
    fHistPt = dynamic_cast<TH1F*> (fOutputList->At(2));
    if (!fHistPt) {
        printf("ERROR: fHistPt not available\n");
        return;
    }
    
    fHistEta = dynamic_cast<TH1F*> (fOutputList->At(3));
    if (!fHistEta) {
        printf("ERROR: fHistEta not available\n");
        return;
    }
    
///////////////////////////////////////////////////////////
   
    TCanvas *cfHistVertex = new TCanvas("fHistVertex",
    "fHistVertex", 10,10,510,510);
    cfHistVertex->cd(1)->SetLogy();
    fHistVertex->SaveAs("vertex_LHC17h_CMSHr.root");
    fHistVertex->DrawCopy("E");

    TCanvas *cpDCA = new TCanvas("fHistpDCA","fHistpDCA",
    10,10,510,510);
    cpDCA->cd(1)->SetLogz();
    fHistpDCA->DrawCopy("colz");
    fHistpDCA->SaveAs("ptvspdca_LHC17h_CMSH.root");
    
    TCanvas *cPt = new TCanvas("Pt","Pt",10,10,510,510);
    cPt->cd(1)->SetLogy();
    fHistPt->DrawCopy("E");
    fHistPt->SaveAs("pt_LHC17h_CMSH.root");

    TCanvas *cEta = new TCanvas("Eta","Eta",10,10,510,510);
    cEta->cd(1)->SetLogy();
    fHistEta->DrawCopy("E");
    fHistEta->SaveAs("eta_LHC17h_CMSH.root");
    
///////////////////////////////////////////////////////////
    
}
