#include "Riostream.h"  
#include "TH1F.h"
#include "THStack.h"
#include "TGraphAsymmErrors.h"
#include "TGraphErrors.h"
void assymmGraffa2() 
{  
   TH1D *hcharm = new TH1D("charm","p_{T} Distribution",72,0.25,18.25);
   TH1D *hbeaut = new TH1D("beauty","beauty",72,0.25,18.25 );
   TH1D *hbtoc = new TH1D("beauty2c","beauty2c", 72,0.25,18.25);
        hcharm->GetXaxis()->SetTitle("p_{T} (GeV/c)");
	hcharm->GetYaxis()->SetTitle("d#sigma/dp_{T} (counts/GeV/c)");
   TH1D *hsum = new TH1D("hsum","hsum",72,0.25,18.25);
//    const char *  texPtY="#it{#sigma}_{#mu #leftarrow W} (nb)";
     TH1F *htotal = 0;
     hsum->GetXaxis()->SetTitle("pT");
   
   TCanvas *c1 = new TCanvas("FONLL", "FONLL", 800, 600); 
   c1->SetGrid();
   c1->cd()->SetLogy();

    
 
//    TH1F* hframe = c1->DrawFrame(-6.,1e-4,6.,9.e5);

   ifstream fbeaut,fbtoc,fcharm;
   fbeaut.open("pt_b_to_e.txt");   
   fbtoc.open("pt_b_to_d_e.txt");
   fcharm.open("pt_c_to_e.txt"); 
   
    Float_t binc,centc,xminc,xmaxc,min_scc,max_scc,min_masc,max_masc,min_pdfc,max_pdfc;
    Float_t binb,centb,xminb,xmaxb,min_scb,max_scb,min_masb,max_masb,min_pdfb,max_pdfb;
    Float_t binbd,centbd,xminbd,xmaxbd,min_scbd,max_scbd,min_masbd,max_masbd,min_pdfbd,max_pdfbd;
    Float_t minerr, maxerr;

 Float_t cc[120],bc[120], bdc[120], cl[120], bl[120], bdl[120], cu[120], bu[120],bdu[120];
          Float_t x[120], evl[120], evh[120];

    Int_t i=1;
    while (i<73) {
    string dummyLine;
//    getline(stream, dummyLine);
// // Begin reading your stream here
// while (stream) 
//        if (!fcharm.good()) break;	
      fcharm >> binc >> centc  >> xminc  >> xmaxc  >> min_scc  >> max_scc  >> min_masc  >> max_masc >> min_pdfc >> max_pdfc;
      fbeaut >> binb >> centb  >> xminb  >> xmaxb  >> min_scb  >> max_scb  >> min_masb  >> max_masb >> min_pdfb >> max_pdfb;
      fbtoc >> binbd >> centbd >> xminbd >> xmaxbd >> min_scbd >> max_scbd >> min_masbd >> max_masbd >> min_pdfbd >> max_pdfbd;
 
          x[i] = binc;

	cc[i] = centc;
	cl[i] = xminc;
	cu[i] = xmaxc;
      
	bc[i] = centb;
	bl[i] = xminb;
	bu[i] = xmaxb;
	
	bdc[i] = centbd;
	bdl[i] = xminbd;
	bdu[i] = xmaxbd;
	
	cout << i <<"  "<< x[i] << "  " << bl[i] << endl;
       hbeaut->SetBinContent(hbeaut->FindBin(x[i]),bc[i]);
       hbtoc->SetBinContent(hbtoc->FindBin(x[i]),bdc[i]);
       hcharm->SetBinContent(hcharm->FindBin(x[i]),cc[i]);
 
//  hbe->SetBinContent(i,y[i]);
//  hbde->SetBinContent(i,z[i]);
//  hcharm->SetBinContent(x[i,v[i]);
 i++;
      
    }
     TCanvas *cs = new TCanvas("cs","cs",10,10,600,600);
     cs->cd();
//     THStack *hs = new THStack("hs","Stacked 1D histograms");
    //Histogram
    
    hcharm->SetFillColor(kRed);
    hcharm->SetFillStyle(3004);
    hcharm->SetLineWidth(1);
    hcharm->SetLineColor(kRed);
    hcharm->Draw("hist");
//  hs->Add(hcharm);
    hcharm->Sumw2();
    hcharm->SaveAs("hcharm.root","recreate");
    
    hbeaut->SetFillColor(kBlue);
    hbeaut->SetFillStyle(3004);
    hbeaut->SetLineWidth(1);
    hbeaut->SetLineColor(kBlue);
//     hs->Add(hbeaut);
    hbeaut->Draw("histsame");
    hbeaut->Sumw2();
     hbeaut->SaveAs("hbeaut.root","recreate");
     
    hbtoc->SetFillColor(kGreen);
    hbtoc->SetFillStyle(3004);
    hbtoc->SetLineWidth(1);
    hbtoc->SetLineColor(kGreen);
    hbtoc->Draw("histsame");
// hs->Add(hbtoc);
    hbtoc->Sumw2();
     hbtoc->SaveAs("hbtoc.root","recreate");
    
    
    hsum->Add(hcharm);
    hsum->Add(hbeaut);
    hsum->Add(hbtoc);
    hsum->Sumw2();
    hsum->SetLineColor(kBlack);
    
    hsum->Draw("esame");
    


 
 
//  hs->Draw("");
    
     TFile* fi = TFile::Open("fonnl_pt_central.root","recreate");
     hsum->Write();
     fi->Close();

  
//   fcharm.close();
//   fbtoc.close();
//   fbeaut.close();


}
