#include "Riostream.h"  
#include "TH1F.h"
#include "TGraphAsymmErrors.h"
#include "TGraphErrors.h"
TH1D* histogram();
void SetStyle(Bool_t graypalette=kFALSE);
double function(double* px,double* p);
double atlas(double* px,double* p);
void fit_pt() 
{  
 TH1D* hsum = 0;
 hsum = histogram();
 SetStyle();
 c = new TCanvas;
 c->SetLogy();
 TPad *pad1 = new TPad("pad1","pad1",0,0.4,1,1);
 pad1->SetLogy();
 pad1->SetBottomMargin(0);
 pad1->Draw();

 TPad *pad2 = new TPad("pad2","pad2",0,0,1,0.4);
 pad2->SetTopMargin(0);
 pad2->SetBottomMargin(0.25);
 pad2->Draw();
 gStyle->SetOptFit(1);
 float p0, p1, p2, p3, p4, p5, p6, p7;
 TF1* func = new TF1("fun",function,0.,18.,8);
        /*****************************************
     * pp: ALERT parameters from beauty_fit.C
     * ***************************************/
  
//     func->SetParameter(0, 4.09900e+03 );
//     func->SetParameter(1, 1.50645e+00);
//     func->SetParameter(2, 4.34030e+08);
//     func->SetParameter(3, 1.60278e+00);
   
   /**********
     * pPb
     * **********/
//     func->FixParameter(0, 2.62143e+06);
//     func->FixParameter(1, 0.53    );
//     func->FixParameter(2, 3.40149e+08);
//     func->FixParameter(3, 1.37       );

  p0 = -1420.44;
  p1 = 1.76177;
  p2 = -0.176876;
  p3 = -2.48111; 
  p4 = 1.89569; 
  p5 = 28614.9;
  p6 = -64420.2;
  p7 = -266495;
      
  func->SetParameter(0, p0);
  func->SetParameter(1, p1);
  func->SetParameter(2, p2);
  func->SetParameter(3, p3);
  func->SetParameter(4, p4);
  func->FixParameter(5, p5);
  func->SetParameter(6, p6);
  func->SetParameter(7, p7);
  
  hsum->Fit("fun","ER0Q+","",0.,18.);
  hsum->Fit("fun","ER0Q+","",0.,18.);
  hsum->Fit("fun","ER0+","",0.,18.);
  hsum->GetYaxis()->SetTitle("d#sigma/dp_{T}");
  pad1->cd();
  hsum->SetLineColor(kBlue);
  hsum->Draw("hist");
  func->SetLineColor(kGreen);
  func->Draw("same");
  
  cout << "  p0 = " << func->GetParameter(0)<<";"  <<endl;
  cout << "  p1 = " << func->GetParameter(1)<<";"  <<endl;
  cout << "  p2 = " << func->GetParameter(2)<<";"  <<endl;
  cout << "  p3 = " << func->GetParameter(3)<<";"  <<endl;
  cout << "  p4 = " << func->GetParameter(4)<<";"  <<endl;
  cout << "  p5 = " << func->GetParameter(5)<<";"  <<endl;
  cout << "  p6 = " << func->GetParameter(6)<<";"  <<endl;
  cout << "  p7 = " << func->GetParameter(7)<<";"  <<endl;
  
  gStyle->SetOptTitle(0);
  pad2->cd();
//   cc = new TCanvas;
 TH1D *hratio = (TH1D*)hsum->Clone("ratio");
 hratio->Sumw2();
//  hfunc->Draw();
//  hsum->Draw("same");
  hratio->Divide(func);
  hratio->GetYaxis()->SetRangeUser(0.2,1.5);
  hratio->GetXaxis()->SetLabelSize(0.05);
  hratio->GetYaxis()->SetLabelSize(0.05);
  hratio->GetYaxis()->SetTitle("FONLL/Fit");
  hratio->GetXaxis()->SetTitle("p_{T} (GeV/c)");
  hratio->GetXaxis()->SetTitleSize(0.1);
  hratio->SetLineWidth(1.2);
 
  hratio->Fit("pol1","R0","",0.,18.);
  hratio->Draw("hist");
  hratio->GetFunction("pol1")->Draw("same");
  
}

TH1D* histogram(){
  TFile* file = TFile::Open("fonnl_pt_central.root","read"); 
  hsum = (TH1D*)file->Get("hsum");
  return hsum;
}

double function(double* px,double* p){

// muon pT

  Double_t x=*px;
   //if( x < 1. ) return 0.;
  Float_t p0,p1,p2,p3, p4, p5, p6, p7;
  p0 = p[0];
  p1 = p[1];
  p2 = p[2];
  p3 = p[3];
  p4 = p[4];
  p5 = p[5];
  p6 = p[6];
  p7 = p[7];

  // norm
  Float_t norm = p0;
  //slope
  Float_t slope = p1 * ( 1. - TMath::Exp( p2*x)) + p3;
  //double 
  Float_t den = 1./TMath::Power(x,p4);
  // pol
  Float_t pol = p5 + p6*x+p7*x*x;

  return norm * TMath::Exp( slope*x ) * den * pol;
  
}

double atlas(double* px,double* p){
 // as used be ATLAS
  Double_t x=*px;
//   if( x < 1. ) return 0.;
//   double x = (1+PAR)*xx[0];
  double a = p[0];
  double b = p[1];
  double c = p[2];
  double d = p[3];

  double f1 = a*TMath::Exp(-b*x);
  double f2 = c*TMath::Exp(-d*TMath::Sqrt(x))/TMath::Power(x,2.5);
  return f1+f2;
 }
void SetStyle(Bool_t graypalette) {
  cout << "Setting style!" << endl;
  
  gStyle->Reset("Plain");
  gStyle->SetOptTitle(0);
  gStyle->SetOptStat(0);
  if(graypalette) gStyle->SetPalette(8,0);
  else gStyle->SetPalette(1);
  gStyle->SetCanvasColor(10);
  gStyle->SetCanvasBorderMode(0);
  gStyle->SetFrameLineWidth(1);
  gStyle->SetFrameFillColor(kWhite);
  gStyle->SetPadColor(10);
  gStyle->SetPadTickX(1);
  gStyle->SetPadTickY(1);
  gStyle->SetPadBottomMargin(0.15);
  gStyle->SetPadLeftMargin(0.15);
  gStyle->SetHistLineWidth(1);
  gStyle->SetHistLineColor(kRed);
  gStyle->SetFuncWidth(2);
  gStyle->SetFuncColor(kRed);
  gStyle->SetLineWidth(2);
  gStyle->SetLabelSize(0.045,"xyz");
  gStyle->SetLabelOffset(0.01,"y");
  gStyle->SetLabelOffset(0.01,"x");
  gStyle->SetLabelColor(kBlack,"xyz");
  gStyle->SetTitleSize(0.08,"xyz");
  gStyle->SetTitleOffset(1.25,"y");
  gStyle->SetTitleOffset(1.2,"x");
  gStyle->SetTitleFillColor(kWhite);
  gStyle->SetTextSizePixels(26);
  gStyle->SetTextFont(42);
  //  gStyle->SetTickLength(0.04,"X");  gStyle->SetTickLength(0.04,"Y"); 

  gStyle->SetLegendBorderSize(0);
  gStyle->SetLegendFillColor(kWhite);
  //  gStyle->SetFillColor(kWhite);
  gStyle->SetLegendFont(42);


}
