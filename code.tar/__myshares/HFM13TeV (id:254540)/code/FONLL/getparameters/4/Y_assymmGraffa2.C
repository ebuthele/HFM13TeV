#include "Riostream.h"  
#include "TH1F.h"
#include "TGraphAsymmErrors.h"
#include "TGraphErrors.h"
void Y_assymmGraffa2() 
{  
    TH1D *hc = new TH1D("charm","charm",240,0.,6);
    TH1D *hbe = new TH1D("beauty","beauty",240,0.,6);
    TH1D *hbde = new TH1D("beauty2c","beauty2c",240,0.,6);
    TH1D *hsum = new TH1D("hsum","hsum",240,0.,6);
//    
    TH1D *hc = new TH1D("charm","charm",6,-4.,-2.5);
    TH1D *hbe = new TH1D("beauty","beauty",6,-4.,-2.5);
    TH1D *hbde = new TH1D("beauty2c","beauty2c",6,-4.,-2.5);
    TH1D *hsum = new TH1D("hsum","hsum",6,-4.,-2.5);
   
     TH1F *htotal = 0;
   TCanvas *c1 = new TCanvas("FONLL", "FONLL", 800, 600); 
//    c1->SetFillColor(42);
//    c1->SetGrid();
  c1->cd()->SetLogy();

  
//    c1->GetFrame()->SetFillColor(21);
//    c1->GetFrame()->SetBorderSize(12);
//     TH1F* hframe = c1->DrawFrame(0.,1.,20.,1.e7);
  TH1F* hframe = c1->DrawFrame(-4,1.e5,-2.5,1.e8);
  hframe->GetXaxis()->SetTitle("y");
  hframe->GetYaxis()->SetTitle("d#sigma/dy");
  hframe->SetTitle("y Distribution");
//  hframe->GetYaxis()->SetLogy();
    hframe->Draw();
//       hframe->GetXaxis()->CenterTitle( kTRUE );
//       hframe->SetYTitle(texPtY);
//       hframe->GetYaxis()->SetLogy();
     
   ifstream file,fila,filu;
//    file.open("b_to_d_e.txt");   
//    fila.open("b_to_e.txt");
//    filu.open("c_to_e.txt"); 
   file.open("Y_b_to_d_e.txt");   
   fila.open("Y_b_to_e.txt");
   filu.open("Y_c_to_e.txt"); 
   
    Float_t bin,xcent,xmin,xmax;
    Float_t bin,lxcent,lxmin,lxmax;
    Float_t bin,cxcent,cxmin,cxmax;
    Float_t minerr, maxerr;
//     Double_t bin;
    
    int nlines = 0;
    Int_t n = 6;
    Int_t i=0;
    while (i<n) {
 i++; 
      file >> bin >> xcent;
      fila >> bin >> lxcent;
      filu >> bin >> cxcent;
//      	       if (!file.good()) break;
// 	  Float_t x[120],ex[120], y[120], eyl[120], eyh[120], z[120], ezl[120], ezh[120];
//        Float_t v[120], evl[120], evh[120];
//    
//         x[i] = bin;
// 
// 	y[i] = xcent;
//       
// 	z[i] = lxcent;
// 	
// 	v[i] = cxcent;
	
	cout << i <<"  "<< bin << endl;  
	
	
 hbde->SetBinContent(i,xcent);
 hbe->SetBinContent(i,lxcent);
 hc->SetBinContent(i,cxcent);

 
    }
// return;
    hbe->SetLineWidth(1);
    hbe->SetLineColor(kBlue);
    hbe->Draw("esame");
    
    hbde->SetLineWidth(1);
    hbde->SetLineColor(kGreen);
    hbde->Draw("esame");
    
    hc->SetLineWidth(1);
    hc->SetLineColor(kRed);
    hc->Draw("esame");
//    
    
    hsum->Add(hc);
    hsum->Add(hbe);
    hsum->Add(hbde);
    hsum->SetLineColor(kBlack);

//     hsum->Sumw2();
    
   TLegend *leg = new TLegend(0.4,0.6,0.89,0.89);
 leg->AddEntry(hbe,"#mu #leftarrow b","fpl");
 leg->AddEntry(hbde,"#mu #leftarrow D #leftarrow b","fpl");
leg->AddEntry(hc,"#mu #leftarrow c","fpl");
leg->AddEntry(hsum,"ALL","fpl");
 leg->Draw(); 
    hsum->Draw("esame");
    hsum->SaveAs("rapidity.root");

// hsum->SaveAs("Pt.root");
//     hsum->Fit("pol8","","",6.,20.);
    
//     cout <<"p0 = " << 


}
