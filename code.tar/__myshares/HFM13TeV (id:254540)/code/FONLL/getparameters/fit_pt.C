#include "Riostream.h"  
#include "TH1F.h"
#include "TGraphAsymmErrors.h"
#include "TGraphErrors.h"
TH1D* histogram();
void SetStyle(Bool_t graypalette=kFALSE);
double function(double* px,double* p);
double atlas(double* px,double* p);
void fit_pt() 
{  
 TH1D* hsum = 0;
 hsum = histogram();
 SetStyle();
 c = new TCanvas;
 c->SetLogy();
 TPad *pad1 = new TPad("pad1","pad1",0,0.4,1,1);
 pad1->SetLogy();
 pad1->SetBottomMargin(0);
 pad1->Draw();

 TPad *pad2 = new TPad("pad2","pad2",0,0,1,0.4);
 pad2->SetTopMargin(0);
 pad2->SetBottomMargin(0.25);
 pad2->Draw();
 gStyle->SetOptFit(1);
 float p0, p1, p2, p3, p4, p5, p6, p7;
 TF1* func = new TF1("fun",function,0.,18.,8);
        /*****************************************
     * pp: ALERT parameters from beauty_fit.C
     * ***************************************/
  
//     func->SetParameter(0, 4.09900e+03 );
//     func->SetParameter(1, 1.50645e+00);
//     func->SetParameter(2, 4.34030e+08);
//     func->SetParameter(3, 1.60278e+00);
   
   /**********
     * pPb
     * **********/
//     func->FixParameter(0, 2.62143e+06);
//     func->FixParameter(1, 0.53    );
//     func->FixParameter(2, 3.40149e+08);
//     func->FixParameter(3, 1.37       );
// p0 = 687.102;
//   p1 = -0.037844;
//   p2 = 0.00830884;
//   p3 = -0.143907;
//   p4 = 4.42142;
//   p5 = 434346;
//   p6 = 5115.85;
//   p7 = 419.854;
/*
  p0 = 324.185;
  p1 = 0.194919;
  p2 = -0.0034537;
  p3 = -0.098346;
  p4 = 4.10474;
  p5 = 2.92489e+06;
  p6 = 46624;
  p7 = -132.992;

  p0 = 324.185;
  p1 = 0.194919;
  p2 = -0.0034537;
  p3 = -0.098346;
  p4 = 4.10474;
  p5 = 2.92489e+06;
  p6 = 46624;
  p7 = -525.376;
*/
   p0 = 90.9318;            // p0 = 71.9318; // Initial values
   p1 = 0.0767759;          // p1 = 0.0767759;
   p2 = -0.0116986;         // p2 = -0.0116986;
   p3 = -0.141098;          // p3 = -0.141098;
   p4 = 4.30578;            // p4 = 4.30578;
   p5 = 3.68992e+06;        // p5 = 3.68992e+06;
   p6 = 8688.87;            // p6 = 8688.87;
   p7 = -132.033;           // p7 = -132.033;

  p0 = 91.5506;
  p1 = 0.100329;
  p2 = -0.0155677;
  p3 = -0.121148;
  p4 = 3.88279;
  p5 = 8.36274e+06;
  p6 = -15384.6;
  p7 = -522.284;

  p0 = 76.07884;//60.5506;
  p1 = 0.0736802; //0.0756802
  p2 = -0.0155677;
  p3 = -0.106949;
  p4 = 3.961; //3.77551;
  p5 = 1.08898e+07;
  p6 = -2015.5;
  p7 = -522.284;

  p0 = 76.0687;
  p1 = 0.0701837;
  p2 = -0.0180871;
  p3 = -0.105136;
  p4 = 3.98549;
  p5 = 1.11167e+07;
  p6 = -1990.02;
  p7 = -263.702;
  
   /*  
   p0 = 427.274;
   p1 = 0.166194;
   p2 = -0.00369529;
   p3 = -0.0984345;
   p4 = 4.42982;
   p5 = 2.85215e+06;
   p6 = 262638;
   p7 = -1212.69;
   */
  
  func->SetParameter(0, p0);
  func->SetParameter(1, p1 );
  func->SetParameter(2, p2);
  func->SetParameter(3, p3);
  func->SetParameter(4, p4 );
  func->SetParameter(5, p5     );
  func->SetParameter(6, p6    );
  func->SetParameter(7, p7    );
  
//   func->SetParameter(0, 4.13770e+02);
//   func->SetParameter(1, -0.0295044 );
//   func->SetParameter(2,-1.75012e-02);
//   func->SetParameter(3,-1.79602e-01);
//   func->SetParameter(4, 3.94451    );
//   func->SetParameter(5, 451834     );
//   func->SetParameter(6, 8321.56    );
//   func->SetParameter(7, 162.92    );
 
  hsum->Fit("fun","ER0Q+","",0.,18.);
  hsum->Fit("fun","ER0Q+","",0.,18.);
  hsum->Fit("fun","ER0+","",0.,18.);
  hsum->GetYaxis()->SetTitle("d#sigma/dp_{T}");
  pad1->cd();
  hsum->Draw("hist");
  func->Draw("same");
  
  cout << "  p0 = " << func->GetParameter(0)<<";"  <<endl;
  cout << "  p1 = " << func->GetParameter(1)<<";"  <<endl;
  cout << "  p2 = " << func->GetParameter(2)<<";"  <<endl;
  cout << "  p3 = " << func->GetParameter(3)<<";"  <<endl;
  cout << "  p4 = " << func->GetParameter(4)<<";"  <<endl;
  cout << "  p5 = " << func->GetParameter(5)<<";"  <<endl;
  cout << "  p6 = " << func->GetParameter(6)<<";"  <<endl;
  cout << "  p7 = " << func->GetParameter(7)<<";"  <<endl;
  
  gStyle->SetOptTitle(0);
  pad2->cd();
//   cc = new TCanvas;
 TH1D *hratio = (TH1D*)hsum->Clone("ratio");
 hratio->Sumw2();
//  hfunc->Draw();
//  hsum->Draw("same");
  hratio->Divide(func);
  hratio->GetYaxis()->SetRangeUser(0.2,1.5);
  hratio->GetXaxis()->SetLabelSize(0.05);
  hratio->GetYaxis()->SetLabelSize(0.05);
  hratio->GetYaxis()->SetTitle("FONLL/Fit");
  hratio->GetXaxis()->SetTitle("p_{T} (GeV/c)");
  hratio->GetXaxis()->SetTitleSize(0.1);
  hratio->SetLineWidth(1.2);
 
  hratio->Fit("pol1","R0","",0,18);
  hratio->Draw("hist");
  hratio->GetFunction("pol1")->Draw("same");
  
}

TH1D* histogram(){
  TFile* file = TFile::Open("fonnl_pt_central.root","read"); 
  hsum = (TH1D*)file->Get("hsum");
  return hsum;
}

double function(double* px,double* p){

// muon pT

  Double_t x=*px;
//   if( x < 1. ) return 0.;
  Float_t p0,p1,p2,p3, p4, p5, p6, p7;
  p0 = p[0];// 1.17314e+03; //
  p1 = p[1];// 9.64518e-02; //
  p2 = p[2];//-1.78926e-02; //
  p3 = p[3];//-1.73028e-01; //
  p4 = p[4];// 4.78214e+00; //
  p5 = p[5];// 8.89662e+04; //
  p6 = p[6];// 1.96674e+03; //
  p7 = p[7];// 1.31215e-03; //

  // norm
  Float_t norm = p0;
  //slope
  Float_t slope = p1 * ( 1. - TMath::Exp( p2*x)) + p3;
  //double 
  Float_t den = 1./TMath::Power(x,p4);
  // pol
  Float_t pol = p5 + p6*x+p7*x*x;

  return norm * TMath::Exp( slope*x ) * den * pol;
  
}

double atlas(double* px,double* p){
 // as used be ATLAS
  Double_t x=*px;
//   if( x < 1. ) return 0.;
//   double x = (1+PAR)*xx[0];
  double a = p[0];
  double b = p[1];
  double c = p[2];
  double d = p[3];

  double f1 = a*TMath::Exp(-b*x);
  double f2 = c*TMath::Exp(-d*TMath::Sqrt(x))/TMath::Power(x,2.5);
  return f1+f2;
 }
void SetStyle(Bool_t graypalette) {
  cout << "Setting style!" << endl;
  
  gStyle->Reset("Plain");
  gStyle->SetOptTitle(0);
  gStyle->SetOptStat(0);
  if(graypalette) gStyle->SetPalette(8,0);
  else gStyle->SetPalette(1);
  gStyle->SetCanvasColor(10);
  gStyle->SetCanvasBorderMode(0);
  gStyle->SetFrameLineWidth(1);
  gStyle->SetFrameFillColor(kWhite);
  gStyle->SetPadColor(10);
  gStyle->SetPadTickX(1);
  gStyle->SetPadTickY(1);
  gStyle->SetPadBottomMargin(0.15);
  gStyle->SetPadLeftMargin(0.15);
  gStyle->SetHistLineWidth(1);
  gStyle->SetHistLineColor(kRed);
  gStyle->SetFuncWidth(2);
  gStyle->SetFuncColor(kRed);
  gStyle->SetLineWidth(2);
  gStyle->SetLabelSize(0.045,"xyz");
  gStyle->SetLabelOffset(0.01,"y");
  gStyle->SetLabelOffset(0.01,"x");
  gStyle->SetLabelColor(kBlack,"xyz");
  gStyle->SetTitleSize(0.08,"xyz");
  gStyle->SetTitleOffset(1.25,"y");
  gStyle->SetTitleOffset(1.2,"x");
  gStyle->SetTitleFillColor(kWhite);
  gStyle->SetTextSizePixels(26);
  gStyle->SetTextFont(42);
  //  gStyle->SetTickLength(0.04,"X");  gStyle->SetTickLength(0.04,"Y"); 

  gStyle->SetLegendBorderSize(0);
  gStyle->SetLegendFillColor(kWhite);
  //  gStyle->SetFillColor(kWhite);
  gStyle->SetLegendFont(42);


}
