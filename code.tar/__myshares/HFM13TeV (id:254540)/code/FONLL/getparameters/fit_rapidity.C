#include "Riostream.h"  
#include "TH1F.h"
#include "TGraphAsymmErrors.h"
#include "TGraphErrors.h"
#include "TStyle.h"

double function(double* xx,double* pp);
void SetStyle(Bool_t graypalette=kFALSE);
void fit_rapidity() 
{
 TH1D* histogram();
//  SetStyle();
 c = new TCanvas;
 c->SetLogy();
 TPad *pad1 = new TPad("pad1","pad1",0,0.4,1,1);
//   pad1->SetLogy();
  pad1->SetBottomMargin(0);
  pad1->Draw();

  TPad *pad2 = new TPad("pad2","pad2",0,0,1,0.4);
  pad2->SetTopMargin(0);
  pad2->SetBottomMargin(0.25);
  pad2->Draw();
  SetStyle();
  gStyle->SetOptFit(1);
 gStyle->SetOptFit(1);  
 TH1D* hsum = 0;
 hsum = histogram();
 hsum->SetLineWidth(3);
  
 TF1* func = new TF1("fun",function,-6,6,6);
 hsum->Fit("fun","ER0Q","",-6,6);
 hsum->Fit("fun","ER0Q","",-6,6);
 hsum->Fit("fun","ER0","",-6,6);
 pad1->cd();
 hsum->GetYaxis()->SetTitle("d#sigma/dy");
 hsum->GetYaxis()->SetLabelSize(0.05);
 hsum->Draw("hist");
 func->Draw("same");
 
  cout << "  p0 = " << func->GetParameter(0)<<";"  <<endl;
  cout << "  p1 = " << func->GetParameter(1)<<";"  <<endl;
  cout << "  p2 = " << func->GetParameter(2)<<";"  <<endl;
  cout << "  p3 = " << func->GetParameter(3)<<";"  <<endl;
  cout << "  p4 = " << func->GetParameter(4)<<";"  <<endl;
  cout << "  p5 = " << func->GetParameter(5)<<";"  <<endl;
 
gStyle->SetOptTitle(0);
  pad2->cd();
//   cc = new TCanvas;
 TH1D *hratio = (TH1D*)hsum->Clone("ratio");
 hratio->Sumw2();
//  hfunc->Draw();
//  hsum->Draw("same");
  hratio->Divide(func);
  hratio->GetYaxis()->SetRangeUser(0.95,1.05);
  hratio->GetXaxis()->SetLabelSize(0.05);
  hratio->GetYaxis()->SetLabelSize(0.07);
  hratio->GetXaxis()->SetTitle("#eta");
  hratio->GetYaxis()->SetTitle("FONLL/Fit");
  hratio->GetXaxis()->SetTitleSize(0.065);
  hratio->SetLineWidth(1.2);
  
  hratio->Fit("pol1","R0","",-6,6);
  hratio->Draw("hist");
  hratio->GetFunction("pol1")->Draw("same");
  hratio->SetLineWidth(3);
  
}

// TH1D* histogram(){
//  TFile* file = TFile::Open("rapidity.root","read"); 
//   hsum = (TH1D*)file->Get("hsum");
//   return hsum;
// }

double function(double* xx,double* pp){

  double x = xx[0];
  double a = pp[5];
  double b = pp[4];
  double c = pp[3];
  double d = pp[2];
  double e = pp[1];
  double f = pp[0];
  
//   double function =  e*TMath::Power(x,4) +  d*TMath::Power(x,3) +  c*TMath::Power(x,2) + b*TMath::Power(x,1) + a;
  double function = a*TMath::Power(x,8) + b*TMath::Power(x,6) +  c*TMath::Power(x,4) +  d*TMath::Power(x,2) + e*TMath::Power(x,1) + f;
  
  return function;
  
}


void SetStyle(Bool_t graypalette) {
  cout << "Setting style!" << endl;
  
  gStyle->Reset("Plain");
  gStyle->SetOptTitle(0);
  gStyle->SetOptStat(0);
  if(graypalette) gStyle->SetPalette(8,0);
  else gStyle->SetPalette(1);
  gStyle->SetCanvasColor(10);
  gStyle->SetCanvasBorderMode(0);
  gStyle->SetFrameLineWidth(1);
  gStyle->SetFrameFillColor(kWhite);
  gStyle->SetPadColor(10);
  gStyle->SetPadTickX(1);
  gStyle->SetPadTickY(1);
  gStyle->SetPadBottomMargin(0.15);
  gStyle->SetPadLeftMargin(0.15);
  gStyle->SetHistLineWidth(1);
  gStyle->SetHistLineColor(kRed);
  gStyle->SetFuncWidth(2);
  gStyle->SetFuncColor(kRed);
  gStyle->SetLineWidth(2);
  gStyle->SetLabelSize(0.045,"xyz");
  gStyle->SetLabelOffset(0.01,"y");
  gStyle->SetLabelOffset(0.01,"x");
  gStyle->SetLabelColor(kBlack,"xyz");
  gStyle->SetTitleSize(0.065,"xyz");
  gStyle->SetTitleOffset(0.5,"y");
  gStyle->SetTitleOffset(0.5,"x");
  gStyle->SetTitleFillColor(kWhite);
  gStyle->SetTextSizePixels(26);
  gStyle->SetTextFont(42);
  //  gStyle->SetTickLength(0.04,"X");  gStyle->SetTickLength(0.04,"Y"); 

  gStyle->SetLegendBorderSize(0);
  gStyle->SetLegendFillColor(kWhite);
  //  gStyle->SetFillColor(kWhite);
  gStyle->SetLegendFont(42);


}
