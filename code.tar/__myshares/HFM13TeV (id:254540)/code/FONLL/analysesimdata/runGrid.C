void runGrid()
{
  // Load common libraries
  gSystem->Load("libCore.so");
  gSystem->Load("libTree.so");
  gSystem->Load("libGeom.so");
  gSystem->Load("libVMC.so");
  gSystem->Load("libPhysics.so");
  gSystem->Load("libMinuit.so");
  gSystem->Load("libSTEERBase");
  gSystem->Load("libESD");
  gSystem->Load("libAOD");
  gSystem->Load("libANALYSIS");
  gSystem->Load("libANALYSISalice");
  gSystem->Load("libCORRFW");
  gSystem->Load("libPWGmuon");
  // Use AliRoot includes to compile our task
  gROOT->ProcessLine(".include $ALICE_ROOT/include");
  gROOT->ProcessLine(".include $ALICE_ROOT/PYTHIA6");
  gROOT->ProcessLine(".include $ALICE_ROOT/include");
  gROOT->ProcessLine(".include $ALICE_PHYSICS/include");
  gROOT->ProcessLine(".include $ALICE_ROOT/lib");


  gSystem->AddIncludePath("-I.");

  // Create and configure the alien handler plugin
  gROOT->LoadMacro("CreateAlienHandler.C");
  AliAnalysisGrid *alienHandler = CreateAlienHandler();
  if (!alienHandler) return;

  // Create the analysis manager
  AliAnalysisManager *mgr = new AliAnalysisManager("testAnalysis");

  // Connect plug-in to the analysis manager
  mgr->SetGridHandler(alienHandler);

//   gROOT->LoadMacro("AliAnalysisTaskPtJ.cxx++g");

  AliAODInputHandler* aodH = new AliAODInputHandler();
  aodH->SetCheckStatistics(kTRUE); // Force to get statistics info from EventStat_temp.root
  mgr->SetInputEventHandler(aodH);
  Bool_t isMC = kTRUE;



  /// Add your analysis here
  gROOT->LoadMacro("$ALICE_PHYSICS/PWG/muon/AddTaskSingleMuonAnalysis.C");
  AliAnalysisTaskSingleMu* singleMuTask = AddTaskSingleMuonAnalysis(isMC);
  if ( isMC ) {
  singleMuTask->GetMuonEventCuts()->SetFilterMask(/*AliMuonEventCuts::kSelectedCentrality|*/AliMuonEventCuts::kSelectedTrig);
  singleMuTask->GetMuonTrackCuts()->SetFilterMask(AliMuonTrackCuts::kMuEta|AliMuonTrackCuts::kMuThetaAbs|AliMuonTrackCuts::kMuPdca|AliMuonTrackCuts::kMuMatchHpt);
  singleMuTask->GetMuonTrackCuts()->SetAllowDefaultParams();
  singleMuTask->SetTerminateOptions("PhysSelPass,PhysSelReject", "ANY","-5_0", "MC verbose");
    }



 // Enable debug printouts
  mgr->SetDebugLevel(0);

  if (!mgr->InitAnalysis())
    return;

 mgr->PrintStatus();
  // Start analysis
//  mgr->StartAnalysis("grid terminate"); // Use this for grid 
 mgr->StartAnalysis("grid terminate"); // Use this for grid
 
  TFile* inf = TFile::Open("/tmp/outSingleMuTask.root");
  TH1D *hprec = (TH1D*) inf->Get("proj0_reconstructed_DecayMu_MuPlus")->Clone("MuPlus");
  TH1D *hmrec= (TH1D*) inf->Get("proj1_reconstructed_DecayMu_MuMinus")->Clone("MuMinus");
  TH1D *htotrec = (TH1D*) inf->Get("proj0_reconstructed_DecayMu_Total")->Clone("MuTotal");

//   hprec->SetTitle("#mu^{+} p_{T} (GeV/c)");
//   hmrec->SetTitle("#mu^{-} p_{T} (GeV/c)");
  htotrec->SetTitle("#mu p_{T} (GeV/c)");

  TFile *outfilerec = new TFile("template.root","recreate");
//   hprec->SetDirectory(outfilerec);
//   hmrec->SetDirectory(outfilerec);
  htotrec->SetDirectory(outfilerec);

//   hprec->Write();
//   hmrec->Write();
  htotrec->Write();

//   outfilerec->Close();
 
//   TH1D *hmp = (TH1D*) inf->Get("proj1_reconstructed_DecayMu_MuPlus")->Clone("MuPlus");
//   TH1D *hmm = (TH1D*) inf->Get("proj1_reconstructed_DecayMu_MuMinus")->Clone("MuMinus");
  TH1D *hmtot = (TH1D*) inf->Get("proj1_reconstructed_DecayMu_Total")->Clone("MuTotal");

//   hmp->SetTitle("#mu^{+} eta");
//   hmm->SetTitle("#mu^{-} eta)");
  hmtot->SetTitle("#mu eta");

  TFile *outfile = new TFile("eta.root","recreate");
//   hmp->SetDirectory(outfile);
//   hmm->SetDirectory(outfile);
  hmtot->SetDirectory(outfile);

//   hmp->Write();
//   hmm->Write();
  hmtot->Write();

  outfile->Close();
 
//   TH1D *hmp = (TH1D*) inf->Get("proj0_generated_DecayMu_MuPlus")->Clone("MuPlus");
//   TH1D *hmm = (TH1D*) inf->Get("proj0_generated_DecayMu_MuMinus")->Clone("MuMinus");
  TH1D *hmtot = (TH1D*) inf->Get("proj1_generated_DecayMu_Total")->Clone("MuTotal");

//   hmp->SetTitle("#mu^{+} eta MC");
//   hmm->SetTitle("#mu^{-} eta MC");
  hmtot->SetTitle("#mu eta MC");

  TFile *outfile = new TFile("etaMC.root","recreate");
//   hmp->SetDirectory(outfile);
//   hmm->SetDirectory(outfile);
  hmtot->SetDirectory(outfile);

//   hmp->Write();
//   hmm->Write();
  hmtot->Write();

  outfile->Close();
 
 
 
//   TH1D *hpmc = (TH1D*) inf->Get("proj0_generated_DecayMu_MuPlus")->Clone("MuPlus");
//   TH1D *hmmc = (TH1D*) inf->Get("proj0_generated_DecayMu_MuMinus")->Clone("MuMinus");
  TH1D *htotmc = (TH1D*) inf->Get("proj0_generated_DecayMu_Total")->Clone("MuTotal");

//   hpmc->SetTitle("#mu^{+} p_{T} (GeV/c)");
//   hmmc->SetTitle("#mu^{-} p_{T} (GeV/c)");
  htotmc->SetTitle("#mu p_{T} (GeV/c)");

  TFile *outfilemc = new TFile("templateMC.root","recreate");
//   hpmc->SetDirectory(outfilemc);
//   hmmc->SetDirectory(outfilemc);
  htotmc->SetDirectory(outfilemc);

//   hpmc->Write();
//   hmmc->Write();
  htotmc->Write();

  outfilemc->Close();
 
 
 
//   TH1D *hpmc = (TH1D*) inf->Get("proj0_Efficiency_DecayMu_MuPlus")->Clone("MuPlusEff");
//   TH1D *hmmc = (TH1D*) inf->Get("proj0_Efficiency_DecayMu_MuMinus")->Clone("MuMinusEff");
  TH1D *htotmc = (TH1D*) inf->Get("proj0_Efficiency_DecayMu_Total")->Clone("MuTotaleff");
 
  TFile *outfile = new TFile("efficiency.root","recreate");
//   hpmc->SetDirectory(outfile);
//   hmmc->SetDirectory(outfile);
  htotmc->SetDirectory(outfile);

//   hpmc->Write();
//   hmmc->Write();
  htotmc->Write();

  outfile->Close();

}