while read a;
do gbbox masterJob $a -status ERROR_ALL resubmit;
done < masterjobs.txt