void muCalc(){

Int_t run;
Double_t l0bMB; // l0b MB rate
Double_t nb; //number of bunches colliding
Double_t premunumerator;
Double_t premudenominator;
Double_t premu; //
Double_t mu; //mu value
Double_t pf; //purity fraction
Double_t fLHC = 11245; //LHC frequency
Double_t fpileup;
Double_t fpileuperror;
///////////////////////////////////////////////////////////

TH1F *hfpileup = new TH1F("fpileup","fpileup",102,0,102);
TH1F *hfpileuperror = new TH1F("fpileup","fpileup",
102,0,102);

TFile *filemb = new TFile("purity/LHC17k_CINT_purity.root");
TH1F hMB = (TH1F)filemb->Get("LHC17k CINT purity"); 

ifstream infMB("LHC17kScalerINT.out");

for(Int_t i=0; i<102; i++){
infMB >> run >> l0bMB >> nb;

pf = hMB->GetBinContent(i+1);

premunumerator = pf*l0bMB;
premudenominator = nb*fLHC;

premu = premunumerator/premudenominator;

 mu = -TMath::Log(1-premu);
 
fpileup = mu/(1 - TMath::Exp(-mu));
///////////////////////////////////////////////////////////

cout << fpileup << endl;
fpileuperror = (1/TMath::Sqrt(pf) + 1/TMath::Sqrt(l0bMB) 
+ 1/TMath::Sqrt(nb) + 1/TMath::Sqrt(fLHC)); 

hfpileup->GetXaxis()->SetBinLabel(i+1,Form("%d",run));
hfpileup->SetBinContent(i+1,fpileup);   

hfpileuperror->SetBinContent(i+1,fpileuperror);
 
}
 TCanvas *cfpileup =  new TCanvas("hfpileup","hfpileup",
 0,0,600,600);
  hfpileup->GetYaxis()->SetTitle("f_{pile-up}");
  hfpileup->GetXaxis()->SetTitle("Run");
  hfpileup->SetTitle("Pileup fraction (pp)");
  hfpileup->GetXaxis()->SetTitleOffset(1.3);
  hfpileup->GetYaxis()->SetTitleOffset(1.3);
  hfpileup->SetLabelSize(0.0235);
  hfpileup->Draw();
  hfpileup->SaveAs("LHC17k_Pileupfraction.root");
}