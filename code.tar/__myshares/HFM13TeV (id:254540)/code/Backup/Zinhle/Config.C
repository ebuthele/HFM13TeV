// Config file MUON + ITS (for vertex) for PDC06
// Tuned for p+p min biais and quarkonia production (AliGenMUONCocktailpp)
// Remember to define the directory and option
// gAlice->SetConfigFunction("Config('$HOME','box');");
// april 3rd: added L3 magnet 
#if !defined(__CINT__) || defined(__MAKECINT__)
#include <Riostream.h>
#include <TRandom.h>
#include <TDatime.h>
#include <TSystem.h>
#include <TVirtualMC.h>
#include <TVirtualMCDecayer.h>
#include <TGeant3TGeo.h>
#include "AliRunLoader.h"
#include "AliRun.h"
#include "AliConfig.h"
#include "AliDecayerPythia.h"
#include "AliGenPythia.h"
#include "AliMagF.h"
#include "AliBODY.h"
#include "AliMAG.h"
#include "AliABSOv3.h"
#include "AliDIPOv3.h"
#include "AliHALLv3.h"
#include "AliFRAMEv2.h"
#include "AliSHILv3.h"
#include "AliPIPEv3.h"
#include "AliITSv11.h"
#include "AliZDCv4.h"
#include "AliFMDv1.h"
#include "AliMUONv1.h"
#include "AliT0v1.h"
#include "AliVZEROv7.h"
#endif 

//--- Functions ---


void ProcessEnvironmentVars();

static Int_t runNumber = 0;
TDatime dt;
static UInt_t seed = dt.Get();

// Comment line
static TString comment;

void Config()
{
 
  // Get settings from environment variables
    ProcessEnvironmentVars();

    gRandom->SetSeed(seed);
    cerr<<"Seed for random number generation= "<<seed<<endl; 
 
    //===============================================================
  //  Libraries required by geant321

#if defined(__CINT__)
  gSystem->AddIncludePath("-I$ALICE_ROOT/include -I$ALICE_PHYSICS/include");
  //gSystem->Load("liblhapdf");      // Parton density function
  //gSystem->Load("libEGPythia6");   // TGenerator interface
    //gSystem->Load("libpythia6");     // Pythia
  //gSystem->Load("libpythia6.4.25");     // Pythia UPGRADED
  //gSystem->Load("libAliPythia6");  // ALICE specific implementations

  gSystem->Load("libgeant321");
#endif

    new TGeant3TGeo("C++ Interface to Geant3");

  //  Create the output file    
    AliRunLoader* rl=0x0;
    cout <<"Config.C: Creating Run Loader ..."<< endl;
    rl = AliRunLoader::Open(
	"galice.root", AliConfig::GetDefaultEventFolderName(), "recreate");
    if (rl == 0x0) {
    gAlice->Fatal("Config.C","Can not instatiate the Run Loader");
    return;
    }
    rl->SetCompressionLevel(2);
    rl->SetNumberOfEventsPerFile(10000);
    gAlice->SetRunLoader(rl);

  //=======================================================================
  // Set External decayer
    TVirtualMCDecayer *decayer = new AliDecayerPythia();
    decayer->SetForceDecay(kAll);
    decayer->Init();
    gMC->SetExternalDecayer(decayer);

  //=======================================================================
  // ******* GEANT STEERING parameters FOR ALICE SIMULATION *******
    gMC->SetProcess("DCAY",1);
    gMC->SetProcess("PAIR",1);
    gMC->SetProcess("COMP",1);
    gMC->SetProcess("PHOT",1);
    gMC->SetProcess("PFIS",0);
    gMC->SetProcess("DRAY",0);
    gMC->SetProcess("ANNI",1);
    gMC->SetProcess("BREM",1);
    gMC->SetProcess("MUNU",1);
    gMC->SetProcess("CKOV",1);
    gMC->SetProcess("HADR",1);
    gMC->SetProcess("LOSS",2);
    gMC->SetProcess("MULS",1);
    gMC->SetProcess("RAYL",1);

    Float_t cut = 1.e-3;        // 1MeV cut by default
    Float_t tofmax = 1.e10;

    gMC->SetCut("CUTGAM", cut);
    gMC->SetCut("CUTELE", cut);
    gMC->SetCut("CUTNEU", cut);
    gMC->SetCut("CUTHAD", cut);
    gMC->SetCut("CUTMUO", cut);
    gMC->SetCut("BCUTE",  cut); 
    gMC->SetCut("BCUTM",  cut); 
    gMC->SetCut("DCUTE",  cut); 
    gMC->SetCut("DCUTM",  cut); 
    gMC->SetCut("PPCUTM", cut);
    gMC->SetCut("TOFMAX", tofmax);

//AliGenerator* gener = CreateGenerator();
  AliGenerator* gener = 0x0;
  std::cout << "GenParamCustomSingleMu settings " << std::endl;
  gSystem->AddIncludePath("-I$ALICE_ROOT/include");
  gSystem->AddIncludePath("-I$ALICE_ROOT/EVGEN");
  gROOT->LoadMacro("GenParamCustomSingleMu.C+");
  //AliGenerator* gener = GenParamCustomSingleMu();
  gener = GenParamCustomSingleMu();
   if (!gener) {
    cout<<"Generator is not set !"<<endl;
    return;
  }

  
  gener->SetOrigin(0., 0., 0.); // Taken from OCDB
  gener->SetSigma(0., 0., 0.);      // Sigma in (X,Y,Z) (cm) on IP position, sigmaz taken from OCDB
//  gener->SetVertexSmear(kPerEvent);
  gener->Init(); 
  gener->Print();

  //============================================================= 
  // Field (L3 0.5 T) outside dimuon spectrometer 
  //AliMagF *field = new AliMagF("Maps","Maps", 2, 1., 1., 10., AliMagF::k5kG);
    //   AliMagF *field = new AliMagF("Maps","Maps", -1., -1., AliMagF::k5kG,AliMagF::kBeamTypepp, 7000/2.0);
    //TGeoGlobalMagField::Instance()->SetField(field);

    rl->CdGAFile();
    
    Int_t iABSO  = 1;
    Int_t iDIPO  = 1;
    Int_t iFMD   = 1;
    Int_t iFRAME = 1;
    Int_t iHALL  = 1;
    Int_t iMAG   = 1;
    Int_t iMUON  = 1;
    Int_t iPHOS  = 0;
    Int_t iPIPE  = 1;
    Int_t iPMD   = 0;
    Int_t iHMPID = 0;
    Int_t iSHIL  = 1;
    Int_t iT0    = 1;
    Int_t iTOF   = 0;
    Int_t iTPC   = 0;

    Int_t iTRD   = 0;
    Int_t iVZERO = 1; 
    Int_t iZDC   = 0;
    Int_t iACORDE= 0;
    Int_t iEMCAL = 0;
    Int_t iITS   = 0;

   //=================== Alice BODY parameters =============================
    AliBODY *BODY = new AliBODY("BODY", "Alice envelop");


    if (iMAG)
    {
        //=================== MAG parameters ============================
        // --- Start with Magnet since detector layouts may be depending ---
        // --- on the selected Magnet dimensions ---
        AliMAG *MAG = new AliMAG("MAG", "Magnet");
    }


    if (iABSO)
    {
        //=================== ABSO parameters ============================
        AliABSO *ABSO = new AliABSOv3("ABSO", "Muon Absorber");
    }

    if (iDIPO)
    {
        //=================== DIPO parameters ============================

        AliDIPO *DIPO = new AliDIPOv3("DIPO", "Dipole version 3");
    }

    if (iHALL)
    {
        //=================== HALL parameters ============================

        AliHALL *HALL = new AliHALLv3("HALL", "Alice Hall");
    }


    if (iFRAME)
    {
        //=================== FRAME parameters ============================

        AliFRAMEv2 *FRAME = new AliFRAMEv2("FRAME", "Space Frame");
	FRAME->SetHoles(1);
    }

    if (iSHIL)
    {
        //=================== SHIL parameters ============================

        AliSHIL *SHIL = new AliSHILv3("SHIL", "Shielding Version 3");
    }


    if (iPIPE)
    {
        //=================== PIPE parameters ============================

        AliPIPE *PIPE = new AliPIPEv3("PIPE", "Beam Pipe");
    }
 
    if (iITS)
    {
        //=================== ITS parameters ============================

//	AliITS *ITS  = new AliITSv11Hybrid("ITS","ITS v11Hybrid");
	AliITS *ITS  = new AliITSv11("ITS","ITS v11");
    }

    if (iTPC)
    {
      //============================ TPC parameters =====================

        AliTPC *TPC = new AliTPCv2("TPC", "Default");
    }


    if (iTOF) {
        //=================== TOF parameters ============================

	AliTOF *TOF = new AliTOFv6T0("TOF", "normal TOF");
    }


    if (iHMPID)
    {
        //=================== HMPID parameters ===========================

        AliHMPID *HMPID = new AliHMPIDv3("HMPID", "normal HMPID");

    }


    if (iZDC)
    {
        //=================== ZDC parameters ============================

        AliZDC *ZDC = new AliZDCv4("ZDC", "normal ZDC");
	//ZDC->SetSpectatorsTrack();	
        //ZDC->SetLumiLength(0.);
    }

    if (iTRD)
    {
        //=================== TRD parameters ============================

        AliTRD *TRD = new AliTRDv1("TRD", "TRD slow simulator");
        AliTRDgeometry *geoTRD = TRD->GetGeometry();
	// Partial geometry: modules at 0,1,7,8,9,16,17
	// starting at 3h in positive direction
	geoTRD->SetSMstatus(2,0);
	geoTRD->SetSMstatus(3,0);
	geoTRD->SetSMstatus(4,0);
        geoTRD->SetSMstatus(5,0);
	geoTRD->SetSMstatus(6,0);
        geoTRD->SetSMstatus(11,0);
        geoTRD->SetSMstatus(12,0);
        geoTRD->SetSMstatus(13,0);
        geoTRD->SetSMstatus(14,0);
        geoTRD->SetSMstatus(15,0);
        geoTRD->SetSMstatus(16,0);
    }

    if (iFMD)
    {
        //=================== FMD parameters ============================

	AliFMD *FMD = new AliFMDv1("FMD", "normal FMD");
   }

    if (iMUON)
    {
        //=================== MUON parameters ===========================
        // New MUONv1 version (geometry defined via builders)
	AliMUON *MUON = new AliMUONv1("MUON", "default");
	// activate trigger efficiency by cells
	MUON->SetTriggerEffCells(1);  // not needed if raw masks
	MUON->SetTriggerResponseV1(2); // cluster size
    }

    if (iPHOS)
    {
        //=================== PHOS parameters ===========================

     AliPHOS *PHOS = new AliPHOSv1("PHOS", "noCPV_Modules123");

    }


    if (iPMD)
    {
        //=================== PMD parameters ============================

        AliPMD *PMD = new AliPMDv1("PMD", "normal PMD");
    }

    if (iT0)
    {
        //=================== T0 parameters ============================
        AliT0 *T0 = new AliT0v1("T0", "T0 Detector");
    }

    if (iEMCAL)
    {
        //=================== EMCAL parameters ============================

        AliEMCAL *EMCAL = new AliEMCALv2("EMCAL", "EMCAL_COMPLETEV1");
    }

     if (iACORDE)
    {
        //=================== ACORDE parameters ============================

        AliACORDE *ACORDE = new AliACORDEv1("ACORDE", "normal ACORDE");
    }

     if (iVZERO)
    {
        //=================== ACORDE parameters ============================

        AliVZERO *VZERO = new AliVZEROv7("VZERO", "normal VZERO");
    }
}

Float_t EtaToTheta(Float_t arg){
  return (180./TMath::Pi())*2.*atan(exp(-arg));
}

void ProcessEnvironmentVars()
{

    // Random Number seed
    if (gSystem->Getenv("CONFIG_SEED")) {
	seed = atoi(gSystem->Getenv("CONFIG_SEED"));
    }
    // Run number
    if (gSystem->Getenv("DC_RUN")) {
      runNumber = atoi(gSystem->Getenv("DC_RUN"));
    }
}

