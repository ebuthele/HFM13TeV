void sim(Int_t nev=5000) {

  gSystem->Load("libpythia6");     // Pythia 6.2 (for decayer)
  AliSimulation simulator;

// simu run/run (no RejectList)
  simulator.SetTriggerConfig("MUON");

  simulator.SetMakeSDigits("MUON");
  simulator.SetMakeDigits("MUON");
  simulator.SetMakeDigitsFromHits("");
  simulator.SetRunQA("MUON:ALL");
  simulator.SetRunHLT("");

//
// Default =  raw OCDB
  simulator.SetDefaultStorage("alien://Folder=/alice/data/2012/OCDB");

// tracking
  simulator.SetSpecificStorage("MUON/Align/Data","alien://folder=/alice/simulation/2008/v4-15-Release/Full");

// Vertex and Mag.field from OCDB
//  simulator.UseVertexFromCDB();
  simulator.UseMagFieldFromGRP();

  TStopwatch timer;
  timer.Start();
  simulator.Run(nev);
  timer.Stop();
  timer.Print();
}

  
   // The rest
  TStopwatch timer;
  timer.Start();
  simulator.Run(nev);
  timer.Stop();
  timer.Print();
}
