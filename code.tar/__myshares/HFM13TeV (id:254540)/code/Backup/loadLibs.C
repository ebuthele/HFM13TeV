#if !defined(__CINT__) || defined(__MAKECINT__)
#include <Riostream.h>
#include "TSystem.h"
#endif

void loadLibs ()
{
  gSystem->Load("libANALYSIS.so");
  gSystem->Load("libOADB.so");
  gSystem->Load("libANALYSISalice.so");
  gSystem->Load("libCORRFW.so");
  gSystem->Load("libPWGmuon.so");
  gSystem->Load("libPWGmuondep.so");
  gSystem->AddIncludePath("-I$ALICE_PHYSICS/PWG/muondep");

  gSystem->Load("liblhapdf");      // Parton density functions
  gSystem->Load("libEGPythia6");   // TGenerator interface
  gSystem->Load("libpythia6_4_25");     // Pythia 6.2
  gSystem->Load("libAliPythia6");  // ALICE specific implementations
  gSystem->AddIncludePath("-I$ALICE_ROOT");
  gSystem->AddIncludePath("-I$ALICE_PHYSICS");
  gSystem->AddIncludePath("-I$ALICE_PHYSICS/PWG");
  gSystem->AddIncludePath("-I$ALICE_PHYSICS/PWG/muondep");
  gSystem->AddIncludePath("-I$ALICE_ROOT/EVGEN");
  gSystem->AddIncludePath("-I$ALICE_ROOT/PYTHIA6");
  gSystem->AddIncludePath("-I$ALICE_ROOT/STEER");
  gSystem->AddIncludePath("-I$ALICE_ROOT/STEER/STEER");
  gSystem->AddIncludePath("-I$ALICE_ROOT/LHAPDF");
  //  TString sMacroName(macroName);
  //  gROOT->ProcessLine(Form(".x %s+", macroName));
}
