void rec()
{
  AliReconstruction reco;
  reco.SetRunQA("MUON:ALL");
  
  reco.SetCleanESD(kFALSE);
  reco.SetStopOnError(kFALSE);
  
  reco.SetDefaultStorage("raw://");
  if ( kFALSE ) reco.SetCDBSnapshotMode("OCDB_rec.root");

  if ( 0 )
  {
    reco.SetRunReconstruction("VZERO T0 MUON ITS FMD");
  }
  else if ( 1 )
  {
    reco.SetRunReconstruction("MUON ITS");
  }
  else
  {
    reco.SetRunReconstruction("MUON");
  }


  // GRP from local OCDB
  reco.SetSpecificStorage("GRP/GRP/Data",Form("local://%s",gSystem->pwd()));

  if ( ! 1 )
  {
    // MUON Tracker Residual Alignment
    reco.SetSpecificStorage("MUON/Align/Data","alien://folder=/alice/simulation/2008/v4-15-Release/Residual");
  }
  
  if ( 0 )
  {
    // ITS
    reco.SetRunPlaneEff(kTRUE);
    reco.SetUseTrackingErrorsForAlignment("ITS");

    reco.SetSpecificStorage("ITS/Align/Data", "alien://folder=/alice/simulation/2008/v4-15-Release/Residual");
    reco.SetSpecificStorage("ITS/Calib/SPDSparseDead", "alien://folder=/alice/simulation/2008/v4-15-Release/Residual");

  }
  else if ( 1 )
  {
    // ITS (use for MC vertex)
    AliITSRecoParam *itsRecoParam = AliITSRecoParam::GetLowFluxParam();
    itsRecoParam->SetVertexerSmearMC();
    itsRecoParam->ReconstructOnlySPD();
    reco.SetRecoParam("ITS",itsRecoParam);
  }

  reco.Run();
}
