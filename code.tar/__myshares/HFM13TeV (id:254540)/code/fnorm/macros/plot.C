#include <TFile.h>
#include <TTree.h>
#include <Riostream.h>


void plot(){
ifstream inf("LHC17kScalerINT.out"); //the file containing the runnumber and purity factor

int nRun = 102; // number of runs

TH1D *hL0b = new TH1D("LHC17k CINT L0b","LHC17k CINT L0b",nRun,0,nRun);
int runnumber;
double purity;


for(int i=0; i<nRun; i++){
inf >> runnumber >> purity;



hL0b->SetBinContent(i+1, purity);
hL0b->GetXaxis()->SetBinLabel(i+1, Form("%d",runnumber));
}

TCanvas *c = new TCanvas();
hL0b->Draw();
hL0b->SaveAs("LHC17k_CINT_L0b.root");

}