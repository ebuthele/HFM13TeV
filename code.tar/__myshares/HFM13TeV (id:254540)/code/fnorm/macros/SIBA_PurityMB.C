void SIBA_PurityMB(){
int runNumber;
double all;
double accepted;
double pumb;
double pumberror;

ifstream inf("16srunallaccmb.txt"); 
                  
                  
TH1F *hPUMB = new TH1F("PUMB","PUMB",75,0,75);
TH1F *hPUMSL = new TH1F("PUMSL","PUMSL",75,0,75);
TH1F *hPUMSH = new TH1F("PUMSH","PUMSH",75,0,75);

for(Int_t i=0; i< 75; i++){
  inf >> runNumber >> all >> accepted >> pumb;
//   cout << runNumber << " " << mb << " " << cmsl << " " << cmsh << endl;  
    
        
pumberror = (1/TMath::Sqrt(all) + 1/TMath::Sqrt(accepted));
 cout << pumb << " " << pumberror << endl;
 
 
    
hPUMB->GetXaxis()->SetBinLabel(i+1,Form("%d",runNumber));
hPUMB->SetBinContent(i+1,pumb);    
hPUMB->SetBinError(i+1,pumberror);

}
  TCanvas *cPUMB = new TCanvas("pumb","pumb",0,0,600,600);
  hPUMB->GetYaxis()->SetTitle("Purity");
  hPUMB->GetXaxis()->SetTitle("Run");
  hPUMB->SetTitle("MB Purity");
//   hPUMB->SetRangeUser(0.95,1.05);
  hPUMB->SetLabelSize(0.0235);
  hPUMB->GetXaxis()->SetTitleOffset(1.3);
  hPUMB->GetYaxis()->SetTitleOffset(1.3);
  hPUMB->Sumw2(); 
  hPUMB->Draw("");
 
  hPUMB->SaveAs("MBPurity.root");

}