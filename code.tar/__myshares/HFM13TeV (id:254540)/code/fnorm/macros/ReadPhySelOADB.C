void ReadPhySelOADB(const UInt_t kBit  = 6,
                    const Int_t  kRun  = 244340,
                    const Int_t  kPass = 2,
                    const Bool_t bpp = kTRUE)
{
  auto file(TFile::Open(AliPhysicsSelection::GetOADBFileName(),"READ"));
  auto pOADBCont(dynamic_cast<AliOADBContainer*>(file->Get("physSel")));
  file->Close();

  if (!pOADBCont) ::Fatal("ReadPhySelOADB::ReadPhySelOADB", "OADB Container is not found");
//=============================================================================

  const TString sName(bpp ? "oadbDefaultPP" : "oadbDefaultPbPb");
  auto psOADB(dynamic_cast<AliOADBPhysicsSelection*>(pOADBCont->GetObject(kRun,sName.Data(),kPass)));

  if (!psOADB) ::Fatal("ReadPhySelOADB::ReadPhySelOADB", "OADB for phys. sel. is not found");
//=============================================================================

  if (kBit>=psOADB->GetNTriggerBits()) {
    ::Fatal("ReadPhySelOADB::ReadPhySelOADB", "%d > trigger bit (= %d)", kBit, psOADB->GetNTriggerBits());
  }
//=============================================================================

  TObjString *pst(nullptr);
  cout << "Coll Trig Classes..." << endl;
  TIter nextBB(psOADB->GetCollTrigClass(kBit));
  while((pst = dynamic_cast<TObjString*>(nextBB()))) cout << pst->String().Data() << endl;
  cout << endl;

  cout << "BG Trig Classes..." << endl;
  TIter nextBG(psOADB->GetBGTrigClass(kBit));
  while((pst = dynamic_cast<TObjString*>(nextBG()))) cout << pst->String().Data() << endl;
//=============================================================================

  return;
}
