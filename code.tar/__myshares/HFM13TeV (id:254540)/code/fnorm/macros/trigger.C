#if defined(__CINT__)
#include "/home/amal/alice/sw/ubuntu1604_x86-64/AliRoot/0-1/include/AliCDBEntry.h"
#include "/home/amal/alice/sw/ubuntu1604_x86-64/AliRoot/0-1/include/AliCDBManager.h"
#include "/home/amal/alice/sw/ubuntu1604_x86-64/AliRoot/0-1/include/AliGRPObject.h"
#include "/home/amal/alice/sw/ubuntu1604_x86-64/AliRoot/0-1/include/AliLog.h"
#include "/home/amal/alice/sw/ubuntu1604_x86-64/AliRoot/0-1/include/AliLHCData.h"
  // Load common libraries
  gSystem->Load("libCore.so");  
  gSystem->Load("libTree.so");
  gSystem->Load("libGeom.so");
  gSystem->Load("libVMC.so");
  gSystem->Load("libPhysics.so");
  gSystem->Load("libMinuit.so");
  gSystem->Load("libSTEERBase");
  gSystem->Load("libESD");
  gSystem->Load("libAOD");
  gSystem->Load("libANALYSIS");
  gSystem->Load("libANALYSISalice");
  gSystem->Load("libCORRFW");
  gSystem->Load("libPWGmuon");
    gSystem->Load("libPWGmuondep");
  // Use AliRoot includes to compile our task
  gROOT->ProcessLine(".include $ALICE_ROOT/include");
  gROOT->ProcessLine(".include $ALICE_PHYSICS/include");
  gROOT->ProcessLine(".include $ALICE_ROOT/lib");
  gROOT->ProcessLine(".include $ALICE_PHYSICS/lib");
  gSystem->AddIncludePath("-I.");
   gROOT->ProcessLine(".include $ROOTSYS/include");
   gROOT->ProcessLine(".include  $ALICE_ROOT/include");
gSystem->SetIncludePath("-I. -I/include -I$ROOTSYS/include -I$ALICE_ROOT/MUON -I$ALICE_ROOT/include -I$ALICE_PHYSICS/include");
  
#endif
// #include "
void trigger()
{
  ofstream ouf2("LHC17kScalerINT.out");
  const char *runListName = "LHC17krunlist.txt";
  if(!runListName) {
    cout << "run list file name does not exist... stop now!" <<endl;
    return NULL;
  }
  ifstream runListFile;
  runListFile.open((char*)runListName);
  Int_t runNr;
  if (runListFile.is_open()) {
    while (kTRUE){
      runListFile >> runNr;
      if(runListFile.eof()) break;
      cout<<runNr<<"\n";
      
    AliAnalysisTriggerScalers scaler(runNr,"raw://");
    AliLHCData* lhc = static_cast<AliLHCData*>(scaler.GetOCDBObject("GRP/GRP/LHCData",runNr));
    
    Int_t NumberOfInteractingBunches(0);
    Int_t NumberOfInteractingBunchesMeasured(0);
    Int_t NIBM2(0);
    
    int beam1(0);
    int beam2(1);
    
    AliLHCDipValI* val = lhc->GetBunchConfigDeclared(beam1,0);
    
    for ( Int_t i = 0; i < val->GetSizeTotal(); ++i )
    {
      if ( val->GetValue(i) < 0 ) ++NumberOfInteractingBunches;
    }
    
    AliLHCDipValI* valm = lhc->GetBunchConfigMeasured(beam1,0);
    
    for ( Int_t i = 0; i < valm->GetSizeTotal(); ++i )
    {
      if ( valm->GetValue(i) < 0 ) ++NumberOfInteractingBunchesMeasured;
    }
    
    valm = lhc->GetBunchConfigMeasured(beam2,0);
    cout << NumberOfInteractingBunches << endl;
    

    AliAnalysisTriggerScalerItem *ts2 = scaler.GetTriggerScaler(runNr,"L0b","CINT7-B-NOPF-MUFAST");
      ouf2 << runNr <<"  " << ts2->Rate() <<"   "<<  NumberOfInteractingBunchesMeasured  << endl;
    }
  }
  else {
    cout << "run list file "<<runListName<<" does not exist... stop now!" <<endl;
    return NULL;
  }
  runListFile.close();
    
}