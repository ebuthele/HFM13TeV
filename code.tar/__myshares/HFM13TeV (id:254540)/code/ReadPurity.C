void ReadPurity()
{
  TFile *file = new TFile("/home/amal/Desktop/fnorm/17h/
  000271868_event_stat.root");
  TH2F *hist= (TH2F*)file->Get("fHistStat");
  hist->SetDirectory(0);
  file->Close();
  Double_t bY = 0;
  Double_t aY = hist->GetYaxis();
  Int_t nBinsY = hist->GetYaxis()->GetNbins();
  for (Int_t i=1; i<=nBinsY; ++i) {
    TString s = hist->GetYaxis()->GetBinLabel(i);
    cout << "BIN =====" << i << "  " << s.Data() << endl;
    if (s.Contains("CMSL7")) {
      bY = i;
      break; 
    }}
  Double_t bX = 0;
  Double_t aX = hist->GetXaxis();
  Int_t nBinsX = hist->GetXaxis()->GetNbins();
  for (Int_t i=1; i<=nBinsX; ++i) {
    TString s = hist->GetXaxis()->GetBinLabel(i);;
    cout << "BIN =====" << i << "  " << s.Data() << endl;
    if (s.Contains("accepted")) {
      bX = i;
      break;
    }}
  const Double_t db = hist->GetBinContent(1,bY);
  const Double_t da = hist->GetBinContent(bX,bY);
  const Double_t dp = da / db;
  cout << bX << endl;
  cout << bY << endl;
    cout << "ALL = " << db << " " 
    << "SEL = " << da << " "
    << "PUL = " << dp << endl;
  cout << db << " " <<  da << " " <<  dp << endl;
  return;
}
